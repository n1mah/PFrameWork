<?php
namespace App\Core;
class Request{
 public function __construct()
 {
     echo "request";
 }   
}